﻿namespace GS_PowerScore.Application.Dtos
{
    public class BeneficiarioEditDto : BeneficiarioDto
    {
    }
}
